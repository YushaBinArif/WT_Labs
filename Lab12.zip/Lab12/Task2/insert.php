<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

$ename = $_GET['empName'];
$empEmail = $_GET['empEmail'];
$empAddr = $_GET['empAddress'];
$empPhn = $_GET['empPhone'];

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO employee VALUES ('$ename', '$empEmail', '$empAddr','$empPhn')";

if (mysqli_query($conn, $sql)) {
    echo "<script> alert('1 record inserted') </script>";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>