<?php

$myFile = "C:/xampp/htdocs/scripts/Test.txt";

$sql = mysql_connect("localhost", "root", "");
if (!$sql) {
    die("Could not connect: " . mysql_error());
}
mysql_select_db("test");
$result = mysql_query("LOAD DATA INFILE '$myFile'" .
                      " INTO TABLE employee FIELDS TERMINATED BY '|'");
if (!$result) {
    die("Could not load. " . mysql_error());
}
else
{
	echo "doneeeeee !!!";
}

?>