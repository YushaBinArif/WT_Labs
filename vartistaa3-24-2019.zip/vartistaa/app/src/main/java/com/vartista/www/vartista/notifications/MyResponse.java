package com.vartista.www.vartista.notifications;

public class MyResponse {

    public  int success;

}
