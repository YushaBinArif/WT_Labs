package com.vartista.www.vartista.modules.provider;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.vartista.www.vartista.R;

public class ServiceProviderPushNotify extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_provider_push_notify);
    }
}
